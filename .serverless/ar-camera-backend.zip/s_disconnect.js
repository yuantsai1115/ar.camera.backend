
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'yuanhao',
  applicationName: 'ar-camera-backend',
  appUid: 'JGB8qRwKfFckrP37pr',
  orgUid: '8d2cb107-fa6d-4546-b214-1e2ae2fce2ca',
  deploymentUid: 'f6adfe08-8528-46de-a167-bd6b830f251c',
  serviceName: 'ar-camera-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.3.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ar-camera-backend-dev-disconnect', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.disconnect, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}